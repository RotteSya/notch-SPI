# NotchSPI 工程交接

- `role`: 本仓库的工程交接入口；测试前阅读 [网络隔离与统计排除记录](docs/test-network-isolation-2026-10-21.md)，历史源码副本须先同步隔离修复。
- `repo_root_resolution`: 包含本文件、`Package.swift` 与 `VERSION.env` 的目录。用 `git rev-parse --show-toplevel` 确认。
- `conflict_policy`: 代码和测试表示当前行为。本文件指出事实所在的文件，不复制配置值和接口字段。专项文档不另写启动步骤。
- `last_verified_commit`: `00975d2de609bb2515059e4214de2b9d1e3aa19b`

NotchSPI 是 Apple Silicon 上的 macOS 学习助手。热键或菜单截取题目，经官方服务、自定义 API Key 或本机 CLI 流式展示讲解，合格的成功结果进入本机最近查题。三条通道都是现有功能。源码版本以 `VERSION.env` 为准。已发布客户端和生产服务各自记录版本；本次交接验收没有重新核对线上部署。

## 1. 阅读规则与当前边界

`AGENTS.md` 与 `CLAUDE.md` 只指向本文件。产品介绍见 [README.md](README.md)。

已实现：刘海窗口、Carbon 热键、截图与题组、三通道路由、流式答案、公式、Ghost 等待、本机最近查题、官方账户与题包、72 小时每日 400 次体验、中日英界面。行为细节见 [docs/client-behavior.md](docs/client-behavior.md)。

3.0 候选：Plus ¥69/月自动续费、每日 400 次，包含购买、取消续费、账单管理和每日权益账本。生产入口由 PLUS_ENABLED 控制；待发布确认。

QA：Plus 离线设计样例、完整答案窗口。入口和未实现边界见 [docs/prototypes.md](docs/prototypes.md)。

已从产品入口移除：本地题库。旧文件留在 Application Support，应用不再读取。

源码里的调度 cron 为空。这是仓库默认值。线上定时任务以部署证据为准，见 [docs/cloudflare-scheduler.md](docs/cloudflare-scheduler.md)。

## 2. 五分钟启动

合格工具链：macOS 14+、arm64、Xcode 命令行工具与 Swift 5.9+、npm，以及 `server/package.json` 的 `engines.node`。`scheduler/package.json` 必须声明同一下限。

```sh
./scripts/bootstrap.sh --run
```

成功时，loopback 的 `/healthz` 为 mock、sqlite、stub。脚本接着打开 bundle `com.rottesya.notchspi.dev`，传入 `http://127.0.0.1:<端口>` 和官方通道。该开发包在读取凭证、账户、设置和网络之前使用进程内临时凭证；本次启动传入的官方通道用于这一进程。直接打开该 App 时，进程提示通过 `./scripts/bootstrap.sh --run` 启动，并在服务初始化前退出。退出应用后，脚本只停止它启动的服务。正式 App、`./scripts/run-local.sh` 和 `./scripts/design-qa.sh` 按各自入口运行。该包使用独立偏好和 ad-hoc 签名。

准备会联网安装两个 npm 锁文件并编译调试客户端。运行不需要模型密钥、生产数据库或 Developer ID。已有 NotchSPI（含正式包、QA 包或开发包）运行时，`--run` 在准备前及启动前拒绝继续并显示 PID；先从该 App 菜单退出再重试，避免两个实例响应同一全局快捷键。脚本不会关闭现有 App，默认准备和 `--check` 仍可运行。端口被占用时退出并显示端口，不结束占用进程。安装前的脚本测试只使用自带样例。工作区的 `node_modules` 在 `npm ci` 之后，由 `./scripts/bootstrap.sh --check` 和 `./scripts/verify.sh` 核对。

Plus 支付回跳的本机隔离沙箱：`python3 scripts/plus-sandbox/prepare.py` 从 output 下源码副本构建专用 bundle；已配置本机 Stripe 沙箱授权后，`node scripts/plus-sandbox/control.mjs start` 启动，`status` 检查，`stop` 停止服务。双击入口与测试步骤位于 `output/plus-native-sandbox/`。该包持久化独立测试账户、只连 loopback、使用独立回跳 scheme；不替代正式签名升级验收。生产修改方案见 [docs/plus-3.0-production-plan.md](docs/plus-3.0-production-plan.md)，尚未执行。

`npm ci` 失败时保留安装错误并停止后续构建。

`./scripts/bootstrap.sh --check` 只核对工具链和锁文件，不安装、不启动。已有账户的本机运行用 `./scripts/run-local.sh`。只起服务用 `./scripts/dev.sh --server-only`，无界面检查用 `./scripts/dev.sh --smoke`。引导样例用 `./scripts/onboarding-qa.sh --mock`，离线界面样例用 `./scripts/design-qa.sh`。

## 3. 运行架构与入口

| 运行单元 | 入口 | 职责 |
| --- | --- | --- |
| macOS 客户端 | `Sources/NotchSPI/App/main.swift` → `AppDelegate` → `NotchController` | AppKit、Carbon 热键、截图、三通道、流式展示、本机历史 |
| Node/Fastify | `server/src/index.ts`；Vercel 为 `server/api/index.ts`，根目录 `server` | 账户、准入、图片验证、供应商、计费、支付、官网、管理 |
| Cloudflare 调度器 | `scheduler/src/index.ts`；候选 `scheduler/src/candidate.ts` | 鉴权调用独立 reap，处理到期恢复 |

主链路：热键或菜单 → 截图与题组 → 官方服务 / 自定义 API Key / 本机 CLI → 流式解析与结算回执 → 刘海答案 → 合格成功结果进入最近查题。

`server/src/storage.ts` 按环境选择 Postgres（`POSTGRES_URL` 或 `DATABASE_URL`）、Serverless 内存或本地 SQLite。三者是条件存储，各自有适配实现。SwiftMath 与 `Vendor/BotAvatarsKit` 随客户端交付，版本以 `Package.swift` 和 `Package.resolved` 为准。`Resources/NotchSPI.png` 是未打包运行时的更新窗口图标。

## 4. 修改导航与事实所有权

| 要修改什么 | 唯一位置 | 必跑测试 |
| --- | --- | --- |
| 版本号 | `VERSION.env` | `scripts/package.sh` 读取它；`repo-health` |
| Swift 平台与依赖 | `Package.swift`、`Package.resolved` | `swift test`、arm64 Release |
| Node 下限与服务依赖 | `server/package.json` 与 lock；scheduler 声明必须一致 | `npm run typecheck`、`npm test` |
| 环境变量 | `server/src/config.ts` 与 `server/.env.example` | `repo-health` |
| HTTP 契约 | `docs/official-api.md` 的路由清单与 `server/src/routes.ts` | `server/test/route-inventory.test.ts` |
| 存储接口 | `server/src/db.ts` 与三个 `db-*.ts` | `db`、`quota-migration` |
| 人格与 objective fixture | `Tests/Fixtures/*/manifest.json` 与 RUNBOOK | 对应 attestation / personality 测试 |
| 评测预算 | `docs/evaluation-budget.json` | `evaluation-budget` |
| 生产模型日预算 | `deploy/production-model-budget.json` | 输出策略测试 |
| 打包 | `scripts/package.sh` | 该脚本的 fail-closed 检查 |
| 回归 | `scripts/verify.sh` | 见第 6 节 |

客户端行为见 [docs/client-behavior.md](docs/client-behavior.md)。兼容字段见 [docs/compatibility.md](docs/compatibility.md)。Objective 放量、停止与回滚的当前规则在 [Tests/Fixtures/objective-v1/RUNBOOK.md](Tests/Fixtures/objective-v1/RUNBOOK.md) 第 4 节。历史调整从 [docs/history/index.json](docs/history/index.json) 进入对应提交。

## 5. 不变量与兼容性

- `INV-BILL-001`：官方成功问答扣 1 题；真实失败不扣。
- `INV-BILL-002`：并发预扣不得产生负余额。
- `INV-AUTH-001`：瞬时 401 保留设备令牌。
- `INV-STREAM-001`：SSE 序列为 `delta`×N → `usage`×1 → `DONE`。
- `INV-CAPTURE-001`：Release 排除本应用的软件截图。
- `INV-DEPLOY-001`：服务端新增契约字段先于客户端部署。
- `INV-STATE-001`：自动模式、人格连续题和截图缓存的生命周期互不泄漏。
- `INV-SECRET-001`：厂商密钥、管理员密钥和数据库凭证不进入 Git 或日志。
- `INV-RESULT-001`：Objective 机器协议不进入可见正文、剪贴板或辅助功能。
- `INV-RESULT-002`：`ready/review` 具有可用答案；`retake` 和无可用结果不扣题。
- `INV-TELEM-001`：产品事件只有固定键和枚举。
- `INV-TELEM-002`：关闭匿名可靠性数据后立即删除队列。
- `INV-PROVIDER-001`：未携带 `result_protocol` 的流量走 `OFFICIAL_PROVIDER`；`objective_v1` 才走 treatment。

热键、体验、旧字段和迁移门槛见 [docs/compatibility.md](docs/compatibility.md) 与 [docs/client-behavior.md](docs/client-behavior.md)。启用 3 天体验时，新注册不再赠送 fixed30 额度；用户主动开始后计时 72 小时。旧 fixed30 账户仅保留兼容，领取体验时替换未用的初始赠送，已购余额保留。旧余额第一次访问建立 `legacy_unknown`。

## 6. 验证及故障定位

`./scripts/verify.sh --quick`：仓库健康检查、检查器测试、服务端类型检查、调度器类型检查、隔离 smoke。

`./scripts/verify.sh` 在此之上运行服务端测试、调度器测试和两份 dry-run 构建、带污染环境变量的 smoke、`NSPI_QA_EPHEMERAL=1` 的串行 Swift 测试（warnings-as-errors）、arm64 Release、资源与不可变证据的固定字节摘要、路由清单、`git diff --check`。

每项写入 `output/verification/<run-id>/`，字段为 name、status、duration_ms、exit_code、test_count、skip_reason、log_path。status 为 passed、failed、skipped 或 blocked。Postgres 在未设置含 `test` 的 `TEST_POSTGRES_URL` 时记 skipped。物理快捷键、录屏权限和签名公证记为 blocked 或 skipped，不计入通过。任一必需项失败则退出码非零；不依赖该失败的检查继续执行。

CI 的平台、Node 与 Postgres 版本矩阵以 `.github/workflows/ci.yml` 为准，覆盖 macOS 串行 Swift 与 Release、AL2023、Vercel 函数包和 Cloudflare scheduler。Node 下限以 `server/package.json` 为准。

隔离 smoke 期望 mock、内存 SQLite 和 stub payments。服务从空环境启动，调用方壳层里的生产变量不会进入进程。

## 7. 尚未验证的事项

- `last_verified_commit` 指向被测源码提交，之后的文档证据更新不改变该源码。结果与交付 PR 见 [docs/handover-acceptance.md](docs/handover-acceptance.md)。
- 已验证无项目构建目录和 node_modules 的 GitHub 克隆；全局下载缓存仍保留。完全无缓存或新机器的准备耗时取决于网络和工具链。
- Postgres 矩阵、AL2023 打包和 Vercel 函数包的验证结果见交付 PR 的 CI；本机验证不替代这些平台。
- 物理全局快捷键、屏幕录制允许、拒绝与返回、带刘海与外接屏、真实悬停，需要人在机器前验收。
- 线上部署版本、真实付款和付费模型效果未在本次重新核对。
- `scripts/run-objective-diagnostic.mjs` 直接调用供应商，不经过评测预算模块。见 [docs/prototypes.md](docs/prototypes.md)。

2026-10-17 的设置迭代记录已原样归档至 [历史记录](docs/settings-iteration-history-2026-10-17.md)，以保持本交接入口在仓库规定的篇幅预算内。

### 自动连答扩展上限（2026-10-19）

通用页新增 100 题、无限（中英日）。持久化沿用 autoMaxQuestions：-1 表示无限，0/未设置仍默认 20，有限值上限扩至 100。无限会话进度显示 n/∞，只取消题数上限，仍遵循手动停止、额度/凭证、失败及空闲停止规则。44 项自动连答与设置回归通过；本机预览已更新并验证两个菜单选项与切页保存，验收后恢复原 20 题选择。未发布。

### 设置与 Plus 合并前复核（2026-10-19）

本轮检查并准备提交设置五页改版、账户恢复/题包保护、Plus 客户端与服务端、隔离预览工具及 3.0 候选文档。修复 Plus 非法日期导致空白到期提示，兼容 ISO 时间无小数秒；统一引导、额度提示、官网及支付返回页的「账户与订阅」指引。生产开关仍默认关闭，Vercel Git 自动部署禁用，不创建发布标签、不执行部署或 Stripe 生产操作。

`./scripts/verify.sh` 通过，证据 `output/verification/20261018T162610Z-30828/summary.tsv`：Swift 582 项（4 跳过、0 失败）、服务端 683 项、调度器 17 项、工程检查器 51 项，类型检查、隔离 smoke、arm64 Release、资源和路由检查通过。最后客户端文案修正后专项 40 项通过。此轮未配置 TEST_POSTGRES_URL，Postgres 留待 CI；硬件权限与签名公证未执行。

### 3.0 build 27 发版准备（2026-10-19）

最新源码重新生成 Developer ID 签名、公证及装订的 arm64 DMG，Gatekeeper 和公开版 2.17 升级身份检查通过。VERSION.env 升至 build 27，旧 build 26 仅为历史证据。CI 11 项任务全绿；本轮 quick 检查通过。安装包、源码快照、后端 CI 构建、发布文案及本地更新预览位于 output/release-3.0-build27/。未正式发布或修改生产。详见 [发布准备记录](docs/release-3.0-build27.md) 与 [Windows 开发交接](docs/windows-port-handoff.md)。硬件/权限覆盖升级及生产 Plus 配置仍待对应验收。

### Windows 客户端开发与构建（2026-10-19）

基线为上面的 3.0 build 27。实现、共享边界和未完成验收见 [Windows 交付入口](docs/windows/README.md)。Windows 目标是 Electron，原生 Mac 继续 AppKit；Ghost、截图轨迹/卡片、阅读结构与引导检查点已共享，设置/窗口仍有平台渲染边界；Windows 实机尚未验收。现有 `output/release-3.0-build27/` 不变。

以下命令均在 `native/` 仓库根目录运行，Node **24.16.0+**。Windows 使用 PowerShell，Mac 使用终端。Git 远端/生产不属于这些步骤。

```sh
npm --prefix server ci --include=optional
npm --prefix desktop ci
node scripts/cross-platform/generate.mjs --check
npm --prefix desktop run check
npm --prefix desktop run smoke
npm --prefix desktop run smoke:motion
```

smoke:motion 额外验证真实透明飞入窗口的可见像素、连续取帧期间的可见性与计时连续、完成与取消清理，输出 `desktop/test-output/motion/`。smoke 需要可用图形桌面，并且先退出其他该客户端实例；它等待 renderer 可见态，保存 `desktop/test-output/launch.png` 后退出。Node 测试通过不等于 Windows 图形系统验收。

Windows 10 2004（build 19041）或更新版本的正常交互桌面，额外运行 `npm --prefix desktop run smoke:capture`：通过实际截图适配器核对刘海/飞入不进入题图、普通窗口可截图，并保存像素证据。它只使用合成测试窗口；非 Windows 会明确报告跳过，不计通过。截图保护不再隐藏或恢复 Windows 浮层。该检查已接入 Windows CI；多屏、混合 DPI、远程桌面和外部截图工具仍按 [本轮记录](docs/windows/visible-capture-2026-10-21.md) 实机验收。

开发完整 UI→服务端链路：

```sh
npm --prefix desktop run dev
```

该命令在 **127.0.0.1:18878** 启动现有 Fastify，使用内存数据库、显式 mock 模型、stub 支付依赖（购买禁用）；客户端显示 `Local mock server`。模型输出固定 fixture，不识别题图。退出客户端同时停止本次启动的服务；端口占用时保留原进程并报错。操作：引导内打开账户与订阅→刷新→主动开始体验→返回练习页实际截图，依次完成单图/多图引导；也可稍后继续引导，通过托盘或浮层菜单选择题图文件（`desktop/test/fixtures/question.jpg`）→流式结果→历史。截图则需要操作系统授予权限，不自动绕过权限。

实际服务运行入口：

```sh
npm --prefix desktop start
```

默认同 Mac 官方 API，凭据保存在当前 OS 用户的应用数据目录。官方功能由现有服务器配置决定；尚未上线的 Plus 能力不能因客户端有 UI 就视为可用。自定义 API 在服务与模型配置；CLI 选择原生可执行文件且需要账户 `cli_enabled`。本轮未连接真实账户进行付费查题。

Windows 产物：

```sh
npm --prefix desktop run pack:win
```

Windows x64 上生成 ZIP 和 NSIS；Apple Silicon Mac 上生成 ZIP，避免 Intel-only NSIS helper。ZIP 解压后运行 `NotchSPI Desktop.exe`，保留同目录所有资源；NSIS 在 Windows 运行并按向导安装。输出在 `desktop/dist/`，当前 `NotchSPI-3.0.27-Windows-x64.zip`。当前包未做 Windows 代码签名，不是正式发行。

共享功能迭代：修改 `shared/` 或服务端客观题解析器后生成并检查，提交生成文件供两端直接编译。

```sh
node scripts/cross-platform/generate.mjs
npm --prefix desktop run check
node scripts/cross-platform/prove-shared-change.mjs
./scripts/verify.sh
```

最后两条需要 Mac/Swift。proof 在隔离副本改等待时间 4→5 秒和阅读字号 15→16，验证真实 Intake/ScreenshotRound 与两端阅读组件，主工作区不改值。`VERSION.env` 同时供 Mac 与 Windows 构建；Windows 产品 semver 映射 major.minor.build，例如 3.0 build 27→3.0.27。`.github/workflows/desktop.yml` 从同一提交构建两个 OS，包含平台 smoke、共享回归、Mac 原生 Release、Windows NSIS/ZIP；当前仅创建本地工作流文件，未推送触发云端。

签名发行必须在 Windows release 环境配置 `CSC_LINK`、必要的 `CSC_KEY_PASSWORD`、`NSPI_WINDOWS_PUBLISHER`（证书 subject）和 `NSPI_WINDOWS_UPDATE_URL`（HTTPS generic 更新源）。打包器在配置更新源时强制签名。没有可信 publisher/HTTPS 配置的候选会禁用自动更新；有配置时显式检查/下载/安装，禁止降级且不静默安装。NSIS、`latest.yml`、blockmap 与 ZIP 由同一提交生成，核验 Windows 安装/验签/升级后才能按正式发布流程上传。该脚本始终 `--publish never`，不会替用户发布。


## 2026-10-19 Neon 配额故障修复

详见 `docs/neon-compute-recovery-2026-10-19.md`。生产已部署 dpl_BiBGvjAazTWsmMqfUsgLWzuTBa6s；Cloudflare 调度已保存为每 15 分钟。主工作区已同步代码与测试。数据库仍受免费配额限制，付费升级等待用户确认；不要把 /healthz 200 当作数据库可用。未改动现有 Windows/客户端工作。

2026-10-20 发版审计仍未放行：业务 500、Plus 404、正式 webhook/门户缺项。已完成本地全量、独立 PostgreSQL 和 DMG 身份复核，并冻结包含恢复修复的后端源码；build 27 旧后端预构建包不得直接部署。证据及解除条件见 [发版审计](docs/release-3.0-preflight-2026-10-20.md)。

### 2026-10-20：3.0 发布推进

3.0 已发布，详见 [发布记录](docs/release-3.0-execution-2026-10-20.md)。

### 2026-10-20：3.0 官网同步

三语言官网已上线 3.0 文案和 Windows Coming soon 禁用下载入口；体验、购买、恢复码和升级指引同步。发布隔离与验证记录见 [官网更新记录](docs/website-3.0-2026-10-20.md)。

### 2026-10-21：正式源码 Intel 兼容重制

基于已发布 Mac 3.0 build 27 冻结源码，在 `output/intel-compat-v3.0-clean/source/` 独立适配，产出 3.0 build 28 Intel / macOS 12.3+。没有 Windows 共享代码，15 个核心文件与正式版一致；586 项 Swift（4 跳过、0 失败）、13 项工程检查器、双架构 Release 通过。最终 DMG 已签名、公证和装订，Gatekeeper 通过；源码、补丁、逐文件哈希、包内符号验证与交付包均在 `output/intel-compat-v3.0-clean/`。旧 `dist-intel-compat/NotchSPI.dmg` 已被替代。后续构建使用新目录的冻结源码，不使用含 Windows 工作的主目录。功能差异和实机边界见 [兼容说明](docs/intel-compatibility.md)。旧 Intel 实机仍待验收。GitHub 和官网已新增兼容版下载，原正式版保留，见 [Intel 发布记录](docs/intel-release-2026-10-21.md)。 随后按实际用户 Catalina 10.15.7 重制 build 29，592 项回归（4 跳过、0 失败）、签名公证装订及 Gatekeeper 通过；未替换公开下载，真机待验收，见 [Catalina 交付](docs/catalina-compatibility.md)。
